import os

TEST_DIR = os.path.dirname(os.path.abspath(__file__))


from pysimplesoap.transport import DummyTransport as DummyHTTP
